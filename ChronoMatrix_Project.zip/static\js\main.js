// Utility functions for UI
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerText = message;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s reverse forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Global API Wrapper with JWT
async function apiCall(endpoint, method = 'GET', body = null) {
    const token = localStorage.getItem('token');
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    const res = await fetch(endpoint, options);
    if (!res.ok) {
        if (res.status === 401) {
            localStorage.clear();
            window.location.href = '/';
        }
        throw new Error('API Error');
    }
    return await res.json();
}

// Setup Navigation based on auth
document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.getElementById('nav-links');
    const navUser = document.getElementById('nav-user');
    const token = localStorage.getItem('token');
    
    if (token) {
        navLinks.innerHTML = `
            <li><a href="/dashboard">Dashboard</a></li>
            <li><a href="/lab-lobby">Lab Lobby</a></li>
            <li><a href="/theory-lobby">Theory Lobby</a></li>
            <li><a href="/timetable">Timetable</a></li>
        `;
        
        navUser.innerHTML = `
            <span style="margin-right: 1rem; color: var(--text-muted);">${localStorage.getItem('username')} (${localStorage.getItem('role')})</span>
            <button class="btn btn-secondary" onclick="logout()" style="padding: 0.4rem 1rem;">Logout</button>
        `;
    }
});

function logout() {
    localStorage.clear();
    window.location.href = '/';
}

function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}
