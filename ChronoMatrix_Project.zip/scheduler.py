from models import Schedule, LabRequirement, TheoryRequirement, FacultyAvailability
import random

DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
SLOTS_PER_DAY = 8

def check_conflict(db_session, faculty_id, room_id, day, start_slot, duration):
    # Check if faculty or room is busy during these slots
    for i in range(start_slot, start_slot + duration):
        # A simple check: if any existing schedule overlaps with this slot
        existing = db_session.query(Schedule).filter(
            Schedule.day == day,
            Schedule.slot_index <= i,
            Schedule.slot_index + Schedule.duration_slots > i
        ).filter(
            (Schedule.faculty_id == faculty_id) | (Schedule.room_id == room_id)
        ).first()
        if existing:
            return True
    return False

def generate_timetable(db):
    # Step 1: Clear existing schedules
    db.session.query(Schedule).delete()
    db.session.commit()
    
    # Step 2: Generate Lab Timetable (Priority)
    labs = db.session.query(LabRequirement).all()
    # Sort labs by department priority (assuming subject->dept priority is fetched, here just random or by ID)
    
    for lab in labs:
        duration = 3 if lab.subject.subject_type == 'Core Lab' else 2
        scheduled = False
        
        # Try finding a slot
        for day in DAYS:
            if scheduled: break
            # Valid start slots: must fit in a single half (before short break, before lunch, after lunch)
            # Actually, to keep it simple, just ensure start_slot + duration <= SLOTS_PER_DAY
            # For 3 slots: [0, 1, 2], [4, 5, 6] etc.
            # Avoid crossing breaks if possible, but let's just use strict indices for now.
            valid_starts = [0, 1, 2, 3, 4, 5, 6, 7]
            if duration == 2:
                valid_starts = [0, 1, 4, 6] # avoid breaking across breaks
            elif duration == 3:
                valid_starts = [0, 4, 5]
                
            for slot in valid_starts:
                if slot + duration > SLOTS_PER_DAY: continue
                
                if not check_conflict(db.session, lab.main_faculty_id, lab.room_id, day, slot, duration):
                    # Found a slot!
                    s = Schedule(
                        schedule_type='Lab',
                        subject_id=lab.subject_id,
                        faculty_id=lab.main_faculty_id,
                        asst_faculty_id=lab.asst_faculty_id,
                        room_id=lab.room_id,
                        day=day,
                        slot_index=slot,
                        duration_slots=duration,
                        semester=lab.semester,
                        section=lab.section,
                        batch=lab.batch
                    )
                    db.session.add(s)
                    scheduled = True
                    break
                    
    db.session.commit()

    # Step 3: Generate Theory Timetable
    theories = db.session.query(TheoryRequirement).all()
    for theory in theories:
        hours_needed = theory.weekly_hours
        hours_scheduled = 0
        
        for day in DAYS:
            if hours_scheduled >= hours_needed: break
            # Try to place 1 hour per day
            placed_today = False
            for slot in range(SLOTS_PER_DAY):
                if not check_conflict(db.session, theory.faculty_id, theory.room_id, day, slot, 1):
                    # Check if student group is free
                    student_conflict = db.session.query(Schedule).filter(
                        Schedule.day == day,
                        Schedule.slot_index <= slot,
                        Schedule.slot_index + Schedule.duration_slots > slot,
                        Schedule.semester == theory.semester,
                        Schedule.section == theory.section
                    ).first()
                    
                    if not student_conflict:
                        s = Schedule(
                            schedule_type='Theory',
                            subject_id=theory.subject_id,
                            faculty_id=theory.faculty_id,
                            room_id=theory.room_id,
                            day=day,
                            slot_index=slot,
                            duration_slots=1,
                            semester=theory.semester,
                            section=theory.section
                        )
                        db.session.add(s)
                        hours_scheduled += 1
                        placed_today = True
                        break # Only 1 theory class of same subject per day
            db.session.commit()

    print("Timetable generation complete.")
