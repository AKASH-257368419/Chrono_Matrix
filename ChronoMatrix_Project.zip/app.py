import os
from flask import Flask, request, jsonify, render_template
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from models import db, User, Department, Faculty, Subject, Room, LabRequirement, TheoryRequirement, Schedule, FacultyAvailability
import pymysql

app = Flask(__name__)
CORS(app)

# Database Configuration - using PyMySQL for MySQL connection
# Create DB if it doesn't exist
try:
    conn = pymysql.connect(host='localhost', user='root', password='')
    cursor = conn.cursor()
    cursor.execute('CREATE DATABASE IF NOT EXISTS chrono_matrix')
    conn.commit()
    conn.close()
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/chrono_matrix'
except Exception as e:
    print(f"MySQL connection failed: {e}. Falling back to SQLite.")
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///chrono_matrix.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'chrono_matrix_super_secret_key'

db.init_app(app)
jwt = JWTManager(app)

# ---------------- Routes: HTML Templates ----------------
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/lab-lobby')
def lab_lobby():
    return render_template('lab_lobby.html')

@app.route('/faculty-availability')
def faculty_availability():
    return render_template('faculty_availability.html')

@app.route('/theory-lobby')
def theory_lobby():
    return render_template('theory_lobby.html')

@app.route('/timetable')
def timetable():
    return render_template('timetable.html')

# ---------------- Routes: Authentication ----------------
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')

    user = User.query.filter_by(username=username, role=role).first()
    
    if user and user.check_password(password):
        access_token = create_access_token(identity={'id': user.id, 'role': user.role, 'username': user.username})
        return jsonify(access_token=access_token), 200
    
    return jsonify({"msg": "Bad username or password"}), 401

@app.route('/api/setup', methods=['POST'])
def setup():
    db.create_all()
    # Create default admin if not exists
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin', role='Admin')
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        return jsonify({"msg": "Database initialized and admin created"}), 201
    return jsonify({"msg": "Database already initialized"}), 200

# ---------------- Routes: CRUD ----------------
@app.route('/api/departments', methods=['GET', 'POST'])
def handle_departments():
    if request.method == 'POST':
        data = request.json
        new_dept = Department(name=data['name'], priority=data.get('priority', 1))
        db.session.add(new_dept)
        db.session.commit()
        return jsonify({"msg": "Department added", "id": new_dept.id}), 201
    else:
        depts = Department.query.all()
        return jsonify([{"id": d.id, "name": d.name, "priority": d.priority} for d in depts])

@app.route('/api/faculty', methods=['GET', 'POST'])
def handle_faculty():
    if request.method == 'POST':
        data = request.json
        new_faculty = Faculty(
            name=data['name'],
            home_department_id=data['home_department_id'],
            max_hours_per_day=data.get('max_hours_per_day', 6),
            capability=data.get('capability', 'Both')
        )
        db.session.add(new_faculty)
        db.session.commit()
        return jsonify({"msg": "Faculty added", "id": new_faculty.id}), 201
    else:
        faculty = Faculty.query.all()
        return jsonify([{"id": f.id, "name": f.name, "department": f.home_department.name} for f in faculty])

@app.route('/api/subjects', methods=['GET', 'POST'])
def handle_subjects():
    if request.method == 'POST':
        data = request.json
        new_subject = Subject(
            code=data['code'],
            name=data['name'],
            subject_type=data['subject_type'],
            department_id=data['department_id']
        )
        db.session.add(new_subject)
        db.session.commit()
        return jsonify({"msg": "Subject added", "id": new_subject.id}), 201
    else:
        subjects = Subject.query.all()
        return jsonify([{"id": s.id, "code": s.code, "name": s.name, "type": s.subject_type} for s in subjects])

@app.route('/api/rooms', methods=['GET', 'POST'])
def handle_rooms():
    if request.method == 'POST':
        data = request.json
        new_room = Room(name=data['name'], room_type=data['room_type'])
        db.session.add(new_room)
        db.session.commit()
        return jsonify({"msg": "Room added", "id": new_room.id}), 201
    else:
        rooms = Room.query.all()
        return jsonify([{"id": r.id, "name": r.name, "type": r.room_type} for r in rooms])

@app.route('/api/lab-requirements', methods=['POST'])
def add_lab_requirement():
    data = request.json
    new_req = LabRequirement(
        subject_id=data['subject_id'],
        main_faculty_id=data['main_faculty_id'],
        asst_faculty_id=data.get('asst_faculty_id'),
        room_id=data['room_id'],
        semester=data['semester'],
        section=data['section'],
        batch=data['batch'],
        weekly_hours=data['weekly_hours']
    )
    db.session.add(new_req)
    db.session.commit()
    return jsonify({"msg": "Lab requirement added"}), 201

@app.route('/api/theory-requirements', methods=['POST'])
def add_theory_requirement():
    data = request.json
    new_req = TheoryRequirement(
        subject_id=data['subject_id'],
        faculty_id=data['faculty_id'],
        room_id=data['room_id'],
        semester=data['semester'],
        section=data['section'],
        weekly_hours=data['weekly_hours']
    )
    db.session.add(new_req)
    db.session.commit()
    return jsonify({"msg": "Theory requirement added"}), 201

from scheduler import generate_timetable
@app.route('/api/generate', methods=['POST'])
def generate():
    try:
        generate_timetable(db)
        return jsonify({"msg": "Timetable generated successfully!"}), 200
    except Exception as e:
        return jsonify({"msg": f"Generation failed: {str(e)}"}), 500

@app.route('/api/timetable', methods=['GET'])
def get_timetable():
    semester = request.args.get('semester')
    section = request.args.get('section')
    query = Schedule.query
    if semester: query = query.filter_by(semester=semester)
    if section: query = query.filter_by(section=section)
    
    schedules = query.all()
    result = []
    for s in schedules:
        result.append({
            "id": s.id,
            "type": s.schedule_type,
            "subject": s.subject.name,
            "faculty": s.faculty.name,
            "room": s.room.name,
            "day": s.day,
            "slot_index": s.slot_index,
            "duration": s.duration_slots,
            "batch": s.batch
        })
    return jsonify(result)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
